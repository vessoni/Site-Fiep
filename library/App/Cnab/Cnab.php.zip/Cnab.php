<?php


define('ConstCNRAgencia', 111);
define('ConstCNRConvenio', 111);
define('ConstCNRAgenciaDV', 111);
define('ConstCNRContaDV', 111);
define('ConstCNRConta', 111);
define('ConstCNRNome', 111);



/**
 * Desmonta arquivo CNAB - 240
 *
 * @package default
 * @author Paulo Cesar Garcia
 **/
class App_Cnab_Cnab
{
    private $dados;

    public function __construct($arquivo)
    {
        $this->dados = explode("\n", $arquivo);
    }

    private function limparDados()
    {
        $dados = array();
        foreach ($this->dados as $key => $value)
        {
            if($value) {
                $dados[$key] = $value;
            }
        }
        $this->dados = $dados;
    }

    public function processar()
    {
        $this->limparDados();

        // Verifica se o Arquivo esta vazio.
        //if (!is_array($this->dados)) return 'Arquivo vazio';

        // Validar o Cabecalho do Arquivo, para ver se eh arquivo de retorno e se eh do convenio de eventos.
        //if (is_string($this->ValidarCabecalhoArquivo())) return 'Erro ao ler o cabeçalho';
        echo '<pre>';
        print_r($this->dados); die;
    }


    private function FncValidarData($value)
    {
        return true;
        # code...
    }

    private function FncPossuiSomenteNumeros($value)
    {
        return true;
    }


    public function recuperaPosicao($valor, $inicio, $qtd)
    {
        return substr( $valor, $inicio-1, $qtd );
    }


    public function FncRetirarZerosAEsquerda($str)
    {
        return (int)$str;
    }

    private function Detalhe()
    {


        $Result        = False;

        $lRegistro     = gListaArquivo.Strings[ pIndice ];
        Inc( gLoteNumRegistro );
        Inc( gLinhaGrid );

        stgDados.RowCount     := stgDados.RowCount + 1;
        stgDados.ColCount     := lConstNumColunasReais;
        stgDados.Rows[ stgDados.RowCount - 1 ].Clear;
        stgDados.ColCount     := lConstNumColunasVisiveis;


        $stgDados[$gLinhaGrid][[ $CNRSituacao,         gLinhaGrid ] := '';
        $stgDados[$gLinhaGrid][[ $CNRTipoBaixa,        gLinhaGrid ] := IntToStr( lConstTpBaixarDupNAOPERMITIDO );

        //------------------------------------------------------------------------------------------------
        //                                      REGISTRO "T"
        //------------------------------------------------------------------------------------------------

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Codigo do Banco na Compensacao
        //    INTERVALO: 1 a 3 (3)
        //    CONTEUDO: Númerico igual a "001"
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao($lRegistro, 1, 3 );
        if ($str <> '001' ) {

            return 'Registro T do Lote: Código do Banco de Compensação incorreto.';
        }

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Lote do Servico
        //    INTERVALO: 4 a 7 (4)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 4, 4 );
        if ( $str <> $pNumLote ) {
            return 'Registro T do Lote: Numero do Lote de Serviço incorreto.';
        }

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Tipo de Registro
        //    INTERVALO: 8 a 8 (1)
        //    CONTEUDO: Númerico igual a "3"
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 8, 1 );
        if ($str <> '3' ) {
            return 'Registro T do Lote: Tipo do Registro incorreto.';
        }

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Numero Sequencial Registro no Lote
        //    INTERVALO: 9 a 13 (5)
        //    CONTEUDO: Númerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 9, 5 );
        if ( $str <> $gLoteNumRegistro ) {
            return 'Registro T do Lote: Número Sequencial do Registro no Lote incorreto.';
        }

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Seguimento do Registro Detalhe
        //    INTERVALO: 14 a 14 (1)
        //    CONTEUDO: Alfanumerico igual a "T".
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 14, 1 );
        if ($str <> 'T' ) {
            return ('Registro T do Lote: Seguimento do Registro Detalhe incorreto.');
        }

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Uso Exclusivo FEBRABAN/CNAB
        //    INTERVALO: 15 a 15 (1)
        //    CONTEUDO: Alfanumerico.
        //------------------------------------------------------------------------------------------------
        //    Nao tratado, porque nao importa.

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Codigo de Movimento Retorno
        //    INTERVALO: 16 a 17 (2)
        //    CONTEUDO: Numerica igual a "06" (Liquidacao).
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 16, 2 );
        if ($str <> '06' ) {
            return 'Registro T do Lote: Código de Movimento de Retorno incorreto.';
        }

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Agencia Mantenedora da Conta
        //    INTERVALO: 18 a 22 (5)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 18, 5 );
        if ($str <> ConstCNRAgencia ) {
            return 'Registro T do Lote: Agência Mantenedora da Conta incorreta.';
        }

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Digito Verificador da Agencia
        //    INTERVALO: 23 a 23 (1)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 23, 1 );
        if ($str <> $this->recuperaPosicao( ConstCNRAgenciaDV, strlen( ConstCNRAgenciaDV ), 1 ) ) {
            return 'Registro T do Lote: Dígito Verificador da Agência incorreto.';
        }

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Número da Conta Corrente
        //    INTERVALO: 24 a 35 (12)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 24, 12 );
        if ( $str <> ConstCNRConta ) {
            return 'Registro T do Lote: Número da Conta Corrente incorreto.';
        }

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Digito Verificador da Conta
        //    INTERVALO: 36 a 36 (1)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 36, 1 );
        if ($str <> $this->recuperaPosicao( ConstCNRContaDV, strlen( ConstCNRContaDV ), 1 ) ) {
            return 'Registro T do Lote: Dígito Verificador da Conta incorreto.';
        }

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Dígito Verificador da Agencia e Conta
        //    INTERVALO: 37 a 37 (1)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 37, 1 );
        if trim( $str ) <> '' ) {
            return 'Registro T do Lote: Dígito Verificador da Agência e Conta incorreto.';
        }

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Identificacao do Titulo
        //    INTERVALO: 38 a 57 (20)
        //    CONTEUDO: Alfanumerico
        //------------------------------------------------------------------------------------------------

        //    Os primeiros 7 digitos sao o Convenio.
        $str = $this->recuperaPosicao( $lRegistro, 38, 7 );
        if ( $str <> ConstCNRConvenio ) {
            return 'Registro T do Lote: Identificação do Título (Convênio) incorreta.';
        }

        //    Os proximos 13 digitos sao o Nosso Numero.
        $str = $this->recuperaPosicao( $lRegistro, 45, 13 );
        $str = trim( $str );
        if ( $str = '' && !FncPossuiSomenteNumeros( $str ) ) {
            return 'Registro T do Lote: Identificação do Título (Nosso Número) incorreta.';
        }

        $stgDados[$gLinhaGrid][ $CNRNossoNumero ] = $this->FncRetirarZerosAEsquerda( $str );

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Codigo da Carteira
        //    INTERVALO: 58 a 58 (1)
        //    CONTEUDO: Numerico igual a "1"
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 58, 1 );
        if ($str <> '1' ) {
            return 'Registro T do Lote: Código da Carteira incorreto.';
        }

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Numero do Documento de Cobranca
        //    INTERVALO: 59 a 73 (15)
        //    CONTEUDO: Alfanumerico
        //------------------------------------------------------------------------------------------------
        //    Nao tratado, usado somente em cobranca registrada.

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Data de Vencimento do Titulo
        //    INTERVALO: 74 a 81 (8)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        //    Nao tratado, usado somente em cobranca registrada.


        //------------------------------------------------------------------------------------------------
        //    CAMPO: Valor Nominal do Titulo
        //    INTERVALO: 82 a 96 (15)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 82, 15 );
        if not FncPossuiSomenteNumeros( str ) ) {
        begin

        return ('Registro T do Lote: Valor Nominal do Título incorreto.');
        Exit;

        end;

        $stgDados[$gLinhaGrid][[ $CNRVlrBruto,                 gLinhaGrid ] := FncIntToVlrF( StrToInt( $this->FncRetirarZerosAEsquerda( str ) ) );

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Numero do Banco
        //    INTERVALO: 97 a 99 (3)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 97, 3 );
        if not FncPossuiSomenteNumeros( str ) ) {
        begin

        return ('Registro T do Lote: Número do Banco incorreto.');
        Exit;

        end;

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Agencia Cobradora/Recebedora
        //    INTERVALO: 100 a 104 (5)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 100, 5 );
        if not FncPossuiSomenteNumeros( str ) ) {
        begin

        return ('Registro T do Lote: Agência Cobradora/Recebedora incorreta.');
        Exit;

        end;

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Digito Verificador da Agencia
        //    INTERVALO: 105 a 105 (1)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 105, 1 );
        if not FncPossuiSomenteNumeros( str ) ) {
        begin

        return ('Registro T do Lote: Dígito Verificador da Agência Cobradora/Recebedora incorreto.');
        Exit;

        end;

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Identificacao do Titulo na Empresa
        //    INTERVALO: 106 a 130 (25)
        //    CONTEUDO: Alfanumerico
        //------------------------------------------------------------------------------------------------
        //    Nao tratado, usado somente em cobranca registrada.


        //------------------------------------------------------------------------------------------------
        //    CAMPO: Codigo da Moeda
        //    INTERVALO: 131 a 132 (2)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 131, 2 );
        if ($str <> '09' ) {
        begin

        return ('Registro T do Lote: Código da Moeda incorreto.');
        Exit;

        end;

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Tipo da Inscricao
        //    INTERVALO: 133 a 133 (1)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        //    Nao tratado, nao utilizado.

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Numero da Inscricao
        //    INTERVALO: 134 a 148 (15)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        //    Nao tratado, nao utilizado.

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Nome
        //    INTERVALO: 149 a 188 (40)
        //    CONTEUDO: Alfanumerico
        //------------------------------------------------------------------------------------------------
        //    Nao tratado, nao utilizado.

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Numero do Contr. da Operacao de Credito
        //    INTERVALO: 189 a 198 (10)
        //    CONTEUDO: Alfanumerico
        //------------------------------------------------------------------------------------------------
        //    Nao tratado, nao utilizado.


        //------------------------------------------------------------------------------------------------
        //    CAMPO: Valor da Tarifa / Custas
        //    INTERVALO: 199 a 213 (15)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 199, 15 );
        if not FncPossuiSomenteNumeros( str ) ) {
        begin

        return ('Registro T do Lote: Valor da Tarifa / Custas incorreto.');
        Exit;

        end;

        $stgDados[$gLinhaGrid][[ $CNRVlrTarifa,        gLinhaGrid ] := FncIntToVlrF( StrToInt( $this->FncRetirarZerosAEsquerda( str ) ) );

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Identificacao para Rejeicoes, Tarifas, Custas, Liquidacao e Baixas
        //    INTERVALO: 214 a 223 (10)
        //    CONTEUDO: Alfanumerico
        //------------------------------------------------------------------------------------------------
        //    Nao tratado, nao utilizado.

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Uso Exclusivo FEBRABAN/CNAB
        //    INTERVALO: 224 a 240 (17)
        //    CONTEUDO: Alfanumerico
        //------------------------------------------------------------------------------------------------
        //    Nao tratado, porque nao importa.



        //------------------------------------------------------------------------------------------------
        //------------------------------------------------------------------------------------------------
        //------------------------------------------------------------------------------------------------
        //                                      REGISTRO "U"
        //------------------------------------------------------------------------------------------------
        //------------------------------------------------------------------------------------------------
        //------------------------------------------------------------------------------------------------
        $lRegistro     := gListaArquivo.Strings[ pIndice + 1 ];
        Inc( gLoteNumRegistro );

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Codigo do Banco na Compensacao
        //    INTERVALO: 1 a 3 (3)
        //    CONTEUDO: Númerico igual a "001"
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 1, 3 );
        if ($str <> '001' ) {
        begin

        return ('Registro U do Lote: Código do Banco de Compensação incorreto.');
        Exit;

        end;

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Lote do Servico
        //    INTERVALO: 4 a 7 (4)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 4, 4 );
        if FncStrToInt( str ) <> pNumLote ) {
        begin

        return ('Registro U do Lote: Numero do Lote de Serviço incorreto.');
        Exit;

        end;

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Tipo de Registro
        //    INTERVALO: 8 a 8 (1)
        //    CONTEUDO: Númerico igual a "3"
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 8, 1 );
        if ($str <> '3' ) {
        begin

        return ('Registro U do Lote: Tipo do Registro incorreto.');
        Exit;

        end;

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Numero Sequencial Registro no Lote
        //    INTERVALO: 9 a 13 (5)
        //    CONTEUDO: Númerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 9, 5 );
        if FncStrToInt( str ) <> gLoteNumRegistro ) {
        begin

        return ('Registro U do Lote: Número Sequencial do Registro no Lote incorreto.');
        Exit;

        end;

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Seguimento do Registro Detalhe
        //    INTERVALO: 14 a 14 (1)
        //    CONTEUDO: Alfanumerico igual a "U".
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 14, 1 );
        if ($str <> 'U' ) {
        begin

        return ('Registro U do Lote: Seguimento do Registro Detalhe incorreto.');
        Exit;

        end;

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Uso Exclusivo FEBRABAN/CNAB
        //    INTERVALO: 15 a 15 (1)
        //    CONTEUDO: Alfanumerico.
        //------------------------------------------------------------------------------------------------
        //    Nao tratado, porque nao importa.

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Codigo de Movimento Retorno
        //    INTERVALO: 16 a 17 (2)
        //    CONTEUDO: Numerica igual a "06" (Liquidacao).
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 16, 2 );
        if ($str <> '06' ) {
        begin

        return ('Registro U do Lote: Código de Movimento de Retorno incorreto.');
        Exit;

        end;

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Valor Juros / Multa / Encargos
        //    INTERVALO: 18 a 32 (15)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 18, 15 );
        if not FncPossuiSomenteNumeros( str ) ) {
        begin

        return ('Registro U do Lote: Valor Juros / Multa / Encargos incorreto.');
        Exit;

        end;

        if $this->FncRetirarZerosAEsquerda( str ) <> '' ) {
        $stgDados[$gLinhaGrid][[ $CNRJuros,                  gLinhaGrid ] := FncIntToVlrF( StrToInt( $this->FncRetirarZerosAEsquerda( str ) ) )
        else
        $stgDados[$gLinhaGrid][[ $CNRJuros,                  gLinhaGrid ] := '0,00';

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Valor de Descontos Concedidos
        //    INTERVALO: 33 a 47 (15)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 33, 15 );
        if not FncPossuiSomenteNumeros( str ) ) {
        begin

        return ('Registro U do Lote: Valor de Descontos Concedidos incorreto.');
        Exit;

        end;

        if $this->FncRetirarZerosAEsquerda( str ) <> '' ) {
        $stgDados[$gLinhaGrid][[ $CNRDesconto,               gLinhaGrid ] := FncIntToVlrF( StrToInt( $this->FncRetirarZerosAEsquerda( str ) ) )
        else
        $stgDados[$gLinhaGrid][[ $CNRDesconto,               gLinhaGrid ] := '0,00';

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Valor de Abatimentos Concedidos/Cancelados
        //    INTERVALO: 48 a 62 (15)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 48, 15 );
        if not FncPossuiSomenteNumeros( str ) ) {
        begin

        return ('Registro U do Lote: Valor de Abatimentos Concedidos incorreto.');
        Exit;

        end;

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Valor de IOF Recolhido
        //    INTERVALO: 63 a 77 (15)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 63, 15 );
        if not FncPossuiSomenteNumeros( str ) ) {
        begin

        return ('Registro U do Lote: Valor de IOF Recolhido incorreto.');
        Exit;

        end;

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Valor Pago pelo Sacado
        //    INTERVALO: 78 a 92 (15)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 78, 15 );
        if not FncPossuiSomenteNumeros( str ) ) {
        begin

        return ('Registro U do Lote: Valor Pago pelo Sacado incorreto.');
        Exit;

        end;

        if $this->FncRetirarZerosAEsquerda( str ) <> '' ) {
        begin

        $stgDados[$gLinhaGrid][[ $CNRVlrLqdo,                gLinhaGrid ] := FncIntToVlrF( StrToInt( $this->FncRetirarZerosAEsquerda( str ) ) );
        gArquivoVlrTotalRecebido    := gArquivoVlrTotalRecebido + ( StrToInt( $this->FncRetirarZerosAEsquerda( str ) ) );

        end
        else
        begin

        $stgDados[$gLinhaGrid][[ $CNRVlrLqdo,                gLinhaGrid ] := '0,00';

        end;


        //------------------------------------------------------------------------------------------------
        //    CAMPO: Valor Liquido a ser Creditado
        //    INTERVALO: 93 a 107 (15)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 93, 15 );
        if not FncPossuiSomenteNumeros( str ) ) {
        begin

        return ('Registro U do Lote: Valor Líquido a ser Creditado incorreto.');
        Exit;

        end;

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Valor de Outras Despesas
        //    INTERVALO: 108 a 122 (15)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 108, 15 );
        if not FncPossuiSomenteNumeros( str ) ) {
        begin

        return ('Registro U do Lote: Valor de Outras Despesas incorreto.');
        Exit;

        end;

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Valor de Outros Creditos
        //    INTERVALO: 123 a 137 (15)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 123, 15 );
        if not FncPossuiSomenteNumeros( str ) ) {
        begin

        return ('Registro U do Lote: Valor de Outros Créditos incorreto.');
        Exit;

        end;

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Data da Ocorrencia
        //    INTERVALO: 138 a 145 (8)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 138, 8 );
        Insert( '/', str, 5 );
        Insert( '/', str, 3 );
        if not FncValidarData( str ) ) {
        begin

        return ('Registro U do Lote: Data de Ocorrência incorreta.');
        Exit;

        end;

        $stgDados[$gLinhaGrid][[ $CNRDataOcorrencia,   gLinhaGrid ] := str;

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Data de Efetivacao do Credito
        //    INTERVALO: 146 a 153 (8)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        $str = $this->recuperaPosicao( $lRegistro, 146, 8 );
        Insert( '/', str, 5 );
        Insert( '/', str, 3 );
        if not FncValidarData( str ) ) {
        begin

        return ('Registro U do Lote: Data de Efetivação do Crédito incorreta.');
        Exit;

        end;

        $stgDados[$gLinhaGrid][[ $CNRDataCredito,      gLinhaGrid ] := str;

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Codigo da Ocorrencia
        //    INTERVALO: 154 a 157 (4)
        //    CONTEUDO: Alfanumerico
        //------------------------------------------------------------------------------------------------
        //    Nao tratado, nao informado no retorno.

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Data da Ocorrencia
        //    INTERVALO: 158 a 165 (8)
        //    CONTEUDO: Alfanumerico
        //------------------------------------------------------------------------------------------------
        //    Nao tratado, nao informado no retorno.

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Valor da Ocorrencia
        //    INTERVALO: 166 a 180 (15)
        //    CONTEUDO: Numerico
        //------------------------------------------------------------------------------------------------
        //    Nao tratado, nao informado no retorno.

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Complemento da Ocorrencia
        //    INTERVALO: 181 a 210 (30)
        //    CONTEUDO: Alfanumerico
        //------------------------------------------------------------------------------------------------
        //    Nao tratado, nao informado no retorno.

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Codigo Banco Correspondente Compensacao
        //    INTERVALO: 211 a 213 (3)
        //    CONTEUDO: Alfanumerico
        //------------------------------------------------------------------------------------------------
        //    Nao tratado, nao informado no retorno.

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Nosso Numero Banco Correspondente
        //    INTERVALO: 214 a 233 (20)
        //    CONTEUDO: Alfanumerico
        //------------------------------------------------------------------------------------------------
        //    Nao tratado, nao informado no retorno.

        //------------------------------------------------------------------------------------------------
        //    CAMPO: Uso Exclusivo FEBRABAN/CNAB
        //    INTERVALO: 234 a 240 (7)
        //    CONTEUDO: Alfanumerico
        //------------------------------------------------------------------------------------------------
        //    Nao tratado, porque nao importa.

        $Result := True;

        end;













    }
























} // END class App_Cnab_Desmontar